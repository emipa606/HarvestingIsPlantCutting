﻿# Harvesting Is Plant Cutting

Removes the Harvesting task from Growing and put it in Plant cutting work type instead.

Growing work type has been renamed Sowing.

Note : You can safely remove or add this mod to any save, as it is only patches things from the core mod through Defs.

### Thanks

Special thanks to kaptain_kavern for his mod "Corrected WorkGivers" which I took the orginal code from and modified it to my taste.
